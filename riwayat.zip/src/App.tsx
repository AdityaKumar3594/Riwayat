import React, { useState } from 'react';
import { Palette, ShoppingBag, Map, BookOpen, Users } from 'lucide-react';
import Header from './components/Header';
import QuickAccessCard from './components/QuickAccessCard';
import ImageCarousel from './components/ImageCarousel';
import AuthModal from './components/AuthModal';
import InteractiveMap from './components/InteractiveMap';
import Marketplace from './components/Marketplace';

function App() {
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [activeSection, setActiveSection] = useState<'map' | 'marketplace'>('map');

  const quickAccessSections = [
    {
      title: 'Creator Hub',
      description: 'Share your cultural content and connect with audiences worldwide',
      icon: <Palette className="w-8 h-8 text-indigo-600" />,
      link: '/creator-hub'
    },
    {
      title: 'Marketplace',
      description: 'Discover and purchase authentic cultural products and services',
      icon: <ShoppingBag className="w-8 h-8 text-emerald-600" />,
      link: '/marketplace'
    },
    {
      title: 'Interactive Map',
      description: 'Explore cultural hotspots across India',
      icon: <Map className="w-8 h-8 text-blue-600" />,
      link: '/map'
    },
    {
      title: 'Learning Modules',
      description: 'Master traditional skills through expert-led workshops',
      icon: <BookOpen className="w-8 h-8 text-amber-600" />,
      link: '/learning'
    },
    {
      title: 'Community',
      description: 'Join discussions and connect with culture enthusiasts',
      icon: <Users className="w-8 h-8 text-purple-600" />,
      link: '/community'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100">
      <Header onAuthClick={() => setIsAuthModalOpen(true)} />
      <AuthModal isOpen={isAuthModalOpen} onClose={() => setIsAuthModalOpen(false)} />
      
      <main className="container mx-auto px-4 py-8">
        {/* Hero Section with Image Carousel */}
        <div className="rounded-2xl overflow-hidden mb-12 shadow-lg">
          <ImageCarousel />
          <div className="absolute inset-0 flex items-center z-10">
            <div className="max-w-2xl mx-8">
              <h1 className="text-5xl font-bold text-white mb-4">
                Celebrate Culture, Connect the World
              </h1>
              <p className="text-xl text-gray-200 mb-8">
                Discover, learn, and share the rich cultural heritage of India through our innovative platform
              </p>
              <button 
                onClick={() => setIsAuthModalOpen(true)}
                className="bg-indigo-600 text-white px-8 py-3 rounded-lg text-lg font-semibold hover:bg-indigo-700 transition-colors"
              >
                Get Started
              </button>
            </div>
          </div>
        </div>

        {/* Section Toggle */}
        <div className="flex gap-4 mb-8">
          <button
            onClick={() => setActiveSection('map')}
            className={`px-6 py-3 rounded-lg font-medium transition-colors ${
              activeSection === 'map'
                ? 'bg-indigo-600 text-white'
                : 'bg-white text-gray-700 hover:bg-gray-50'
            }`}
          >
            Interactive Map
          </button>
          <button
            onClick={() => setActiveSection('marketplace')}
            className={`px-6 py-3 rounded-lg font-medium transition-colors ${
              activeSection === 'marketplace'
                ? 'bg-indigo-600 text-white'
                : 'bg-white text-gray-700 hover:bg-gray-50'
            }`}
          >
            Marketplace
          </button>
        </div>

        {/* Active Section Content */}
        {activeSection === 'map' ? <InteractiveMap /> : <Marketplace />}

        {/* Quick Access Section */}
        <h2 className="text-3xl font-bold text-gray-900 my-12">Quick Access</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {quickAccessSections.map((section) => (
            <QuickAccessCard key={section.title} {...section} />
          ))}
        </div>
      </main>
    </div>
  );
}

export default App;