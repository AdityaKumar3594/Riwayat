import React, { useState } from 'react';
import { Search, ShoppingBag, Star, User } from 'lucide-react';

interface Product {
  id: string;
  name: string;
  artisan: string;
  price: number;
  description: string;
  image: string;
  category: string;
  rating: number;
  region: string;
}

const sampleProducts: Product[] = [
  {
    id: '1',
    name: 'Traditional Madhubani Painting',
    artisan: 'Rama Devi',
    price: 12000,
    description: 'Hand-painted Madhubani art depicting rural life scenes',
    image: 'https://as2.ftcdn.net/v2/jpg/09/99/67/45/1000_F_999674555_eAKK7QmCGKGwy1zJ9vIXxg9CcfzOmnyN.jpg',
    category: 'Paintings',
    rating: 4.8,
    region: 'Bihar'
  },
  {
    id: '2',
    name: 'Handwoven Banarasi Silk Saree',
    artisan: 'Mohammad Ismail',
    price: 25000,
    description: 'Pure silk saree with traditional zari work',
    image: 'https://cdn.shopaccino.com/swadescreations/products/pure-katan-silk-handwoven-banarasi-saree---royal-blue-purple-328774_l.jpeg?v=526',
    category: 'Textiles',
    rating: 4.9,
    region: 'Uttar Pradesh'
  }
];

const categories = ['All', 'Paintings', 'Textiles', 'Pottery', 'Jewelry', 'Sculptures'];

const Marketplace: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [cart, setCart] = useState<string[]>([]);

  const filteredProducts = sampleProducts.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         product.artisan.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || product.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const addToCart = (productId: string) => {
    setCart(prev => [...prev, productId]);
  };

  const isInCart = (productId: string) => cart.includes(productId);

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      {/* Search and Categories */}
      <div className="flex flex-wrap gap-4 mb-8">
        <div className="flex-1 min-w-[300px]">
          <div className="relative">
            <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search handcrafted products..."
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>
        <div className="flex gap-2 flex-wrap">
          {categories.map(category => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-colors
                ${selectedCategory === category
                  ? 'bg-indigo-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
            >
              {category}
            </button>
          ))}
        </div>
      </div>

      {/* Products Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredProducts.map(product => (
          <div key={product.id} className="bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-48 object-cover rounded-t-lg"
            />
            <div className="p-4">
              <div className="flex justify-between items-start mb-2">
                <h3 className="text-lg font-semibold">{product.name}</h3>
                <span className="flex items-center gap-1 text-amber-500">
                  <Star className="h-4 w-4 fill-current" />
                  {product.rating}
                </span>
              </div>
              <div className="flex items-center gap-2 text-gray-600 text-sm mb-2">
                <User className="h-4 w-4" />
                <span>{product.artisan}</span>
              </div>
              <p className="text-gray-600 text-sm mb-4">{product.description}</p>
              <div className="flex justify-between items-center">
                <span className="text-lg font-semibold">₹{product.price.toLocaleString()}</span>
                <button
                  onClick={() => addToCart(product.id)}
                  disabled={isInCart(product.id)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium
                    ${isInCart(product.id)
                      ? 'bg-green-100 text-green-800 cursor-not-allowed'
                      : 'bg-indigo-600 text-white hover:bg-indigo-700'
                    }`}
                >
                  <ShoppingBag className="h-4 w-4" />
                  {isInCart(product.id) ? 'Added to Cart' : 'Add to Cart'}
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Marketplace;