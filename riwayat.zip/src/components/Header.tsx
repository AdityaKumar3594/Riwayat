import React from 'react';
import { Globe2 } from 'lucide-react';

interface HeaderProps {
  onAuthClick: () => void;
}

const Header: React.FC<HeaderProps> = ({ onAuthClick }) => {
  return (
    <header className="bg-white shadow-sm">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-2">
            <Globe2 className="w-8 h-8 text-indigo-600" />
            <span className="text-xl font-bold text-gray-900">Riwayat</span>
          </div>
          
          <nav className="hidden md:flex space-x-8">
            <a href="/creator-hub" className="text-gray-600 hover:text-gray-900">Creator Hub</a>
            <a href="/marketplace" className="text-gray-600 hover:text-gray-900">Marketplace</a>
            <a href="/map" className="text-gray-600 hover:text-gray-900">Map</a>
            <a href="/learning" className="text-gray-600 hover:text-gray-900">Learning</a>
            <a href="/community" className="text-gray-600 hover:text-gray-900">Community</a>
          </nav>

          <div className="flex items-center space-x-4">
            <button 
              onClick={onAuthClick}
              className="text-gray-600 hover:text-gray-900"
            >
              Sign In
            </button>
            <button 
              onClick={onAuthClick}
              className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition-colors"
            >
              Join Now
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;