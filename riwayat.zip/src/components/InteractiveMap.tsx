import React, { useState } from 'react';
import { Search, Filter } from 'lucide-react';

interface CulturalEvent {
  id: string;
  title: string;
  type: string;
  date: string;
  location: string;
  description: string;
  image: string;
}

const regions = [
  { id: 'north', name: 'North India', color: 'bg-red-200' },
  { id: 'south', name: 'South India', color: 'bg-blue-200' },
  { id: 'east', name: 'East India', color: 'bg-green-200' },
  { id: 'west', name: 'West India', color: 'bg-yellow-200' },
  { id: 'central', name: 'Central India', color: 'bg-purple-200' },
  { id: 'northeast', name: 'Northeast India', color: 'bg-pink-200' }
];

const categories = [
  'Crafts',
  'Music',
  'Dance',
  'Rituals',
  'Festivals',
  'Cuisine'
];

const sampleEvents: CulturalEvent[] = [
  {
    id: '1',
    title: 'Bharatanatyam Workshop',
    type: 'Dance',
    date: '2024-04-15',
    location: 'Chennai, Tamil Nadu',
    description: 'Learn classical dance from master practitioners',
    image: 'https://images.unsplash.com/photo-1545063914-a1a6ec821c88?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '2',
    title: 'Madhubani Art Exhibition',
    type: 'Crafts',
    date: '2024-04-20',
    location: 'Patna, Bihar',
    description: 'Traditional art exhibition and workshop',
    image: 'https://images.unsplash.com/photo-1624286768741-bf24d2e0f0f3?auto=format&fit=crop&w=800&q=80'
  }
];

const InteractiveMap: React.FC = () => {
  const [selectedRegion, setSelectedRegion] = useState<string | null>(null);
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [searchQuery, setSearchQuery] = useState('');

  const handleRegionClick = (regionId: string) => {
    setSelectedRegion(regionId === selectedRegion ? null : regionId);
  };

  const toggleCategory = (category: string) => {
    setSelectedCategories(prev =>
      prev.includes(category)
        ? prev.filter(c => c !== category)
        : [...prev, category]
    );
  };

  const filteredEvents = sampleEvents.filter(event => {
    const matchesSearch = event.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         event.location.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategories.length === 0 || selectedCategories.includes(event.type);
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      {/* Search and Filter Bar */}
      <div className="flex flex-wrap gap-4 mb-6">
        <div className="flex-1 min-w-[200px]">
          <div className="relative">
            <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search cultural events..."
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>
        <div className="flex gap-2 flex-wrap">
          <Filter className="h-5 w-5 text-gray-600 mt-2.5" />
          {categories.map(category => (
            <button
              key={category}
              onClick={() => toggleCategory(category)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-colors
                ${selectedCategories.includes(category)
                  ? 'bg-indigo-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
            >
              {category}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Interactive Map */}
        <div className="bg-gray-50 rounded-lg p-4">
          <h3 className="text-lg font-semibold mb-4">Explore by Region</h3>
          <div className="grid grid-cols-2 gap-4">
            {regions.map(region => (
              <button
                key={region.id}
                onClick={() => handleRegionClick(region.id)}
                className={`p-4 rounded-lg transition-all ${region.color} 
                  ${selectedRegion === region.id ? 'ring-2 ring-indigo-600 shadow-md' : 'hover:shadow-md'}
                `}
              >
                <span className="font-medium">{region.name}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Events Display */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold mb-4">Cultural Events & Activities</h3>
          {filteredEvents.map(event => (
            <div key={event.id} className="bg-white rounded-lg shadow p-4 hover:shadow-md transition-shadow">
              <div className="flex gap-4">
                <img
                  src={event.image}
                  alt={event.title}
                  className="w-24 h-24 rounded-lg object-cover"
                />
                <div>
                  <h4 className="font-semibold text-lg">{event.title}</h4>
                  <p className="text-gray-600 text-sm">{event.location}</p>
                  <p className="text-gray-500 text-sm">{event.date}</p>
                  <span className="inline-block mt-2 px-3 py-1 bg-indigo-100 text-indigo-800 text-xs rounded-full">
                    {event.type}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default InteractiveMap;